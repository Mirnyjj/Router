/* eslint-disable react/prop-types */
import { useRequestDeletingTodos, useRequestUpdateTodos } from '../hooks'
import { useEffect, useState } from 'react';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import EditNoteIcon from '@mui/icons-material/EditNote';
import CheckIcon from '@mui/icons-material/Check';
import '../App.css'
import './ListItem.css'
import { useParams } from 'react-router-dom';


// eslint-disable-next-line react/prop-types
function TodoPage() {
    const [isEditMode, setIsEditMode] = useState(false);
    const [newText, setNewText] = useState('')
    const { isUpdating, requestUpdateTodos } = useRequestUpdateTodos();
    const { isDeleting, requestDeletingTodos } = useRequestDeletingTodos();

    const [caseMap, setCaseMap] = useState([])
    const [caseMapLoading, setCaseMapLoading] = useState(false)

    const fetchTodoById = async (id) => {
        setCaseMapLoading(true);
        const todoResponse = await fetch(`http://localhost:3000/Tasks/${id}`)
        const todoResult = await todoResponse.json()
        setCaseMap(todoResult);
        setCaseMapLoading(false);
    }

    const { id } = useParams();

    useEffect(() => {
        fetchTodoById(id)
    }, []);

    const { title } = caseMap;




    const onChange = ({ target }) => {
        setNewText(target.value)
    }

    const onOpenUpdateTask = () => setIsEditMode(true);
    const onCloseUpdateTask = () => setIsEditMode(false);


    return (
        <ul className='todos'>
            <li key={id} id={id} className='todosItem'>
                {isEditMode ?
                    <>
                        <input
                            name='todo'
                            type='text'
                            placeholder={title}
                            value={newText}
                            onChange={onChange}
                        />
                        <button disabled={isUpdating} className='ButtonReady' onClick={() => { requestUpdateTodos(id, newText), onCloseUpdateTask() }}>
                            <CheckIcon />
                        </button>
                    </>

                    : <>
                        {title}
                        <button className='ButtonEdit' disabled={isUpdating && isEditMode} onClick={onOpenUpdateTask}>
                            <EditNoteIcon />
                        </button>
                        <button className='ButtonDelete' disabled={isDeleting && isEditMode} onClick={() => requestDeletingTodos(id)}>
                            <DeleteOutlineIcon />
                        </button>
                    </>
                }
            </li>
        </ul>

    )
}
export default TodoPage