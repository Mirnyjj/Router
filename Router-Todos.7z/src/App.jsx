import './App.css';
import { useRequestGetTodos } from './hooks'
import MainPage from './components/MainPageTodos';
import { Route, Routes } from 'react-router-dom';
import TodoPage from './components/TodoPage';

function App() {

  const { isLoading } = useRequestGetTodos();

  return (

    <div className='boardWrapper'>
      {isLoading ? (
        <span className="loader"></span>
      ) : (
        <Routes>
          <Route path='/' element={<MainPage />} />
          <Route path='/todos/:id' element={<TodoPage />} />
        </Routes>
      )}

    </div>


  );
}


export default App
