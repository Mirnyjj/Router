import { useState } from "react";
import { useRequestGetTodos } from "./use-request-get-todos";

export const useRequestDeletingTodos = () => {
  const [isDeleting, setIsDeleting] = useState(false);
  const {fetchTodos} = useRequestGetTodos()
  const requestDeletingTodos = (id) => {
    setIsDeleting(true);
    fetch(`http://localhost:3000/Tasks/${id}`, {
      method: 'DELETE',
    })
      .then((rawResponse) => rawResponse.json())
      .then((response) => {
        fetchTodos();
        console.log('Задача УДАЛЕНА, ответ от сервера', response)
      })
      .finally(() => setIsDeleting(false))
  };
return {
    isDeleting,
    requestDeletingTodos,
}
}