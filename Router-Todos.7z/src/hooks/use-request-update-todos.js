import { useState } from "react";
import { useRequestGetTodos } from "./use-request-get-todos";

export const useRequestUpdateTodos = () => {
  const [isUpdating, setIsUpadating] = useState(false);
  const {fetchTodos} = useRequestGetTodos()

  const requestUpdateTodos = (id, newText) => {
    setIsUpadating(true);
    fetch(`http://localhost:3000/Tasks/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json;charset=utf-8' },
      body: JSON.stringify({
        title: newText,
      })
    })
      .then((rawResponse) => rawResponse.json())
      .then((response) => {
        fetchTodos();
        console.log('Задача изменена, ответ от сервера', response)
      })
      .finally(() => setIsUpadating(false))
  };
return {
    isUpdating,
    requestUpdateTodos,
}
}